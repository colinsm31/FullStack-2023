// Initialize two arrays, one with the numbers and an empty one for odd numbers
const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const odds = [];

// For loop to push odd numbers to oddNumber array
for(let i=0; i<arr.length; i++){
  if(arr[i]%2!=0){
    odds.push(arr[i]);
  }
}

console.log(odds);